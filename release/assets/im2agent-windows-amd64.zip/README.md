# im2agent

`im2agent` 是一个运行在本机的 Go 命令行服务。它通过飞书 WebSocket 长连接接收消息，将消息转发到同一台电脑上的 Codex 桌面应用，并把执行进度、工具状态、审批操作和最终结果更新回飞书。

首版支持中国大陆飞书，代码中的 IM 适配器接口为后续接入钉钉和个人微信预留了边界。

## 支持平台

- Windows x64
- macOS Intel x64
- macOS Apple Silicon arm64

macOS 发布包目前不签名、不公证。

## 快速开始

1. 下载并解压对应平台的 `im2agent` 发布包。
2. 在终端运行 `im2agent`（Windows 为 `im2agent.exe`）。
3. 首次运行且没有配置时，程序会生成二维码 PNG 并使用系统图片查看器自动打开，不受终端字体和缩放影响；终端字符二维码及授权链接会同时保留作为备用。使用飞书手机客户端扫码并确认后，程序会删除临时图片，通过飞书官方设备注册流程创建机器人，并自动申请消息收发、图片/文件访问权限，订阅消息事件和互动卡片回调，然后写入配置。
4. 扫码流程不可用时，程序会自动提示手工输入 App ID 和 App Secret。
5. 配置完成后可选择安装为后台服务：Windows 使用当前用户的任务计划程序（每分钟健康检查），macOS 使用用户级 LaunchAgent。安装后会在用户登录时启动，并在中转进程异常退出后自动重启。
6. 服务会自动启动 Codex 桌面应用，不需要事先手工打开；以后运行时不会重复配置。

机器人在群聊中只处理明确 `@机器人` 的消息，私聊中直接处理消息。每个飞书用户独立保存当前选择的 Codex 任务和最近一次数字列表快照。

macOS 发布归档中的 `im2agent` 已携带 Unix 执行权限，使用系统归档工具解压后无需手工执行 `chmod +x`。如果 macOS 阻止打开未签名文件，可在 Finder 中右键选择“打开”，或在确认文件来源后执行：

```bash
xattr -d com.apple.quarantine ./im2agent
```

## 指令

任务和搜索列表每页 10 条，历史对话每页 5 轮。`<序号>` 始终对应该用户最后收到的同类列表快照，即使服务重启也会保留。

| 指令 | 说明 |
| --- | --- |
| `/project` | 使用互动卡片选择 Codex 已保存项目，或创建项目，并在项目中创建和选择任务 |
| `/project page <页码>` | 使用项目卡片查看指定页 |
| `/task` | 使用交互卡片列出全部未归档任务，按最近活动时间倒序；可在卡片内输入标题创建无目录任务 |
| `/task page <页码>` | 使用任务卡片查看指定页 |
| `/task <序号>` | 选择最近任务列表或搜索结果中的任务 |
| `/task create <标题>` | 创建不绑定工作目录的新任务并自动选择 |
| `/task current` | 查看当前任务、模型、推理强度、权限、工作模式、目标、上下文用量及最近一轮消息 |
| `/task search <关键词>` | 使用交互卡片搜索未归档任务的标题和历史消息正文 |
| `/task search page <页码>` | 使用搜索卡片查看指定页 |
| `/history` | 查看当前所选 Codex 任务最近 5 轮历史，包括桌面端历史；可从任一 Codex 回复创建分支 |
| `/history page <页码>` | 查看该 Codex 任务更早的 5 轮历史 |
| `/plugin` | 使用互动卡片列出已安装并启用的 Codex 插件，以及可在普通消息中输入的 `$技能名` 指令 |
| `/permission` | 显示当前权限模式和 Codex 支持的模式列表 |
| `/permission <序号>` | 从下一轮开始切换当前任务权限模式 |
| `/model`、`/model <序号>` | 查看或从下一轮开始切换模型 |
| `/reasoning`、`/reasoning <序号>` | 查看或从下一轮开始切换推理强度 |
| `/mode`、`/mode <序号>` | 查看或从下一轮开始切换 Codex 原生普通模式、计划模式 |
| `/goal` | 查看当前任务的 Codex 原生目标模式，并通过互动卡片设置、刷新或清除目标 |
| `/goal set <目标>`、`/goal clear` | 使用文本指令设置或清除当前任务目标 |
| `/compact` | 使用 Codex 原生功能压缩当前任务上下文；任务执行中会立即拒绝 |
| `/stop` | 中止当前任务正在运行的轮次；选择该任务的任意用户均可执行 |
| `/restart` | 重启 Codex 桌面应用，恢复连接并自动检查、恢复被中断的任务 |
| `/status` | 查看飞书、Codex 和当前任务运行状态 |
| `/update` | 检查 GitHub `latest` 发布版本；有新版本时通过互动按钮自动升级后台服务 |
| `/help` | 显示指令帮助 |

普通消息支持文本、飞书富文本、图片和文件。任务成功完成后，Codex 本轮生成或修改的 PNG、JPEG、GIF、WebP、BMP 图片会自动逐张回复到触发消息；这也包括截图命令生成并在最终回复中以本机 Markdown 路径引用的图片。本机图片语法会从文字回复中移除，其他本机文件链接会改为文件名提示。其他文件不会上传，完成卡片仍会列出本轮新增或修改文件的相对路径。失败或中止的任务不会发送图片。

Codex 最终回复中的 HTTP/HTTPS 链接，以及指向本机 HTML、PDF、SVG、图片、常见文本或代码文件的 Markdown 链接，会在飞书回复正文下方生成“预览”按钮。点击后，中转服务优先通过本机 Chrome、Edge 或 Chromium 的调试协议等待页面资源完成、滚动触发懒加载并生成一张完整的整页长截图；Markdown 会使用安全的 GitHub 风格排版，CSV 会以首行为表头渲染成表格，代码及其他文本文件会转换为安全的自动换行预览页，避免浏览器下载文件后一直等待。macOS 本机文件在没有 Chromium 浏览器时会回退到 Quick Look。截图作为该回复卡片的新回复发送，不会写入 Codex 对话历史；生成失败或超时会使用独立的新请求明确返回错误，重复点击同一项时会提示正在处理中。网页截图不可用时仍可通过正文中的原链接直接打开。可通过 `IM2AGENT_BROWSER` 环境变量指定 Chromium 系浏览器可执行文件。

飞书的 `/task` 和 `/task search` 会返回交互式卡片，可直接选择任务、翻页、刷新，或点击“创建任务”后在原卡片内输入标题。当前任务信息始终显示上下文已用量、窗口上限和百分比；切换任务后还会显示最后一次用户消息、最后一次 Codex 回复、当前工作模式和目标状态，并提供“历史对话”“修改标题”和“压缩上下文”按钮。任务摘要只读取最近一轮；只有点击历史按钮或发送 `/history` 才会读取分页历史。修改标题可直接在原卡片内完成，压缩按钮会直接执行且不会把指令写入 Codex 对话历史。卡片创建的新任务不绑定项目或工作目录，并会自动成为当前任务。群聊卡片只允许发起该卡片的用户操作，其他用户需要自行发送 `/task` 获取独立卡片；文本序号和分页指令仍然保留，供不支持交互卡片的 IM 适配器使用。

`/plugin` 会将 Codex 的插件目录与技能目录合并，只显示已安装并启用的插件。插件下的对话指令使用 Codex 原生 `$技能名` 形式，例如 `$browser:control-in-app-browser`；没有可直接调用技能的插件也会明确标注。`/mode` 写入 Codex 原生 collaboration mode，计划模式不是提示词模拟，并沿用当前任务的模型和推理强度。`/goal` 使用 Codex 原生目标接口；启用后 Codex 会持续推进目标，卡片可查看执行状态、Token 用量和耗时。

飞书的 `/project` 会列出 Codex 桌面端已保存的本机项目。点击项目后只需填写任务标题即可创建任务；点击“创建项目”可在卡片内填写绝对路径和任务标题。路径不存在时服务会创建目录，存在时直接使用。新项目通过官方 Codex CLI 注册到桌面端，新任务会绑定该目录并自动成为当前飞书用户所选任务。

飞书普通消息会作为用户消息写入当前所选 Codex 任务，因此会同步出现在 Codex 桌面端；`/history` 读取该任务的全部轮次，不区分轮次来自飞书还是桌面端，并会过滤 Codex 桌面端自动附加的内部 UI 环境信息。历史中的图片会从文字卡片中移除并逐张作为独立图片消息发送；飞书未声明消息图片 `image_key` 的固定有效期，因此程序会按机器人 App ID 和图片 SHA-256 持久化复用，图片内容变化或飞书拒绝旧 Key 时自动重新上传。每条 Codex 回复下方都有“分支”按钮，点击后会使用 Codex 原生分支能力保留到该回复所在轮次，创建并切换到新的未归档任务；源任务不受影响。历史正文不会按单条消息截断；单页超过飞书卡片大小限制时会自动分段发送，并在末尾保留翻页和刷新按钮。斜杠控制指令和卡片操作不会写入 Codex 对话正文。

## 执行与审批

- 一轮执行使用同一张飞书交互卡片持续更新，显示任务标题、执行状态、Codex 输出、工具名称与状态，以及本轮文件列表。
- 同一任务执行期间的新消息会立即通过 `turn/steer` 作为补充消息注入当前轮次。
- Codex 的命令、文件修改和额外权限审批会私聊发送给触发本轮的飞书用户。
- 审批卡片支持“允许一次”“本任务始终允许”“拒绝”。等待外部审批时，服务会暂停 Codex 的 elicitation 超时计数。
- 如果机器人无法私聊审批用户，操作会自动拒绝，并在原会话提示用户先与机器人建立单聊。
- Codex 未运行或连接中断时，中转服务会自动启动桌面应用并最多重试 3 次；恢复期间新消息立即提示稍后重试，不排队。
- Codex 或中转服务异常退出时，活动任务及其进度卡会持久化。重新连接后，已完成但尚未送达的结果会作为新消息补发，未完成任务会在原 Codex 对话中自动继续。连续 3 次无法启动 Codex 时会停止自动重启并通知受影响的飞书用户，手动启动 Codex 后仍会自动恢复。
- Windows 和 macOS 均使用操作系统文件锁防止同一配置启动多个实例；重复双击只会提示服务已运行并退出。服务连接成功和正常退出时，会向每位用户最后使用的飞书会话发送一条新通知，同一群聊会自动去重。
- Windows 后台模式启动后会立即隐藏自身控制台窗口，任务计划仍直接管理服务进程；直接运行程序进行首次扫码和手工诊断时仍保留可见终端。

已有配置的安装可以手工管理后台服务：

```bash
im2agent --help
im2agent --install-service
im2agent --start-service
im2agent --stop-service
im2agent --restart-service
im2agent --service-status
im2agent --uninstall-service
```

`--stop-service` 会停止但保留后台服务注册和配置。Windows 会同时禁用任务计划，macOS 会禁用 LaunchAgent，因此不会被定时触发或下次登录立即拉起；执行 `--start-service` 会自动重新启用。`--service-status` 显示运行状态、后台程序路径和最后报告的版本。

## 单文件自动更新

正式版本号使用 `vYYYY.MMDD.HHMM` 格式，例如 `v2026.0817.0930`。可执行 `im2agent --version` 查看程序自身版本，也可以在飞书中通过 `/help` 查看当前服务版本。

对于已经安装为后台服务的 Windows 或 macOS 机器，只需要把新的编译文件发给用户。用户直接双击新文件时，如果程序检测到另一位置存在已安装且正在运行的 im2agent 后台服务，会自动进入更新流程：

1. 显示旧程序路径、当前更新文件路径和新旧版本，并要求用户确认。
2. 新版本不高于旧版本时不执行替换，只提示停止后台服务的命令；旧版本无法读取或格式无法比较时给出警告并要求再次确认。
3. 在旧程序旁保留一份 `.backup` 备份，停止旧服务并替换程序。
4. 重新注册并启动后台服务，持续检查新服务是否稳定运行且报告了新版本。
5. 更新或启动失败时自动恢复备份并重新启动旧版本。
6. 无论成功、取消或失败，终端都会等待用户按 Enter，不会立即关闭；下载的新文件不会自动删除。

自动更新只会在“后台服务已安装且正在运行，并且双击的是另一个位置的新文件”时触发。如果没有正在运行的后台服务，新文件仍按普通终端模式启动，不会替换任何程序。配置、任务状态、日志和附件均保存在独立的数据目录中，不会被程序更新覆盖。

如果双击的程序版本与后台服务相同或更低，程序不会显示更新详情或失败信息，只会给出后台服务完整路径对应的 `--stop-service` 停止命令；双击正在运行的已安装程序本身时行为相同。

## 飞书在线更新

已安装并正在运行的后台服务可以在飞书中发送 `/update`，也可以点击帮助卡片中的“检查更新”：

1. 服务从 [`qdog2012/im2agent-release`](https://github.com/qdog2012/im2agent-release) 查询标签固定为 `latest` 的 Release，并比较程序内置的 `vYYYY.MMDD.HHMM` 版本号。
2. `/update` 回复会显示 Release 正文中的发布说明、发布时间和当前平台附件；发现更高版本后再显示“立即升级”按钮，相同版本或本机版本更高时不会降级。
3. 点击按钮后重新查询一次 `latest`，随后最多重试下载三次。下载先写入独立 `.part` 临时目录，并校验 GitHub 附件大小、GitHub 提供的 SHA-256、压缩包完整性、目标程序唯一性，以及新程序执行 `--version` 后的版本号。
4. 只有全部下载与校验通过，才启动独立升级器停止、备份和替换后台服务。Windows 升级器会脱离原任务计划运行，必要时使用独立临时任务，避免停止旧服务时同时终止升级器；macOS 使用独立进程会话。
5. 下载、校验或启动升级器失败时不会停止当前服务；替换后的新服务启动或版本验证失败时会自动回滚并重新启动旧版本。升级或回滚完成后，新启动的服务会把成功或具体失败原因更新回原升级卡片；详细过程同时写入 `logs/self-update.log`。

在线更新不适用于前台运行实例或已停止的后台服务，此时 `/update` 仍会显示检查结果，但不会提供可执行的升级操作。

`latest` Release 的名称或正文必须包含唯一的规范版本号，正文还必须包含面向用户的“更新内容”和源代码提交号，并固定提供以下三个附件名：

- `im2agent-windows-amd64.zip`
- `im2agent-macos-amd64.tar.gz`
- `im2agent-macos-arm64.tar.gz`

三个归档的根目录都必须包含程序文件（Windows 为 `im2agent.exe`，macOS 为 `im2agent`），macOS 归档中的程序权限必须为 `0755`。每次提交并推送正式版本后，都应使用同一内置版本重新构建三个平台，并更新发布仓库的 `latest` Release 文件与发布说明；发布说明应概括从上个发布版本以来的用户可见变化。先完整上传并核验三个附件，再更新 Release 正文中的版本号和更新内容，避免客户端看到尚未完整上传的新版本。

维护者发布时使用 SSH 仓库地址，不需要在本机保存 GitHub API Token。准备好三个归档和发布说明后执行：

```powershell
.\scripts\publish-latest.ps1 -Version v2026.0826.1234 -NotesFile .\dist\release-v2026.0826.1234\notes.md
```

脚本会在上传前重建两个 macOS `tar.gz` 的权限元数据，强制 `im2agent` 为 `0755`、说明和配置文件为 `0644`，并校验执行位；随后通过 `git@github.com:qdog2012/im2agent-release.git` 推送临时 `publish` 分支。发布仓库内的 GitHub Actions 使用仓库自身的短期权限校验文件、更新 `latest` 附件和说明，脚本再通过公开 API 等待并核验最终结果。

## 配置与数据目录

Windows：

- 配置与状态：`%AppData%\im2agent\`
- 附件缓存：`%LocalAppData%\im2agent\attachments\`

macOS：

- 配置与状态：`~/Library/Application Support/im2agent/`
- 附件缓存：`~/Library/Caches/im2agent/attachments/`

完整示例见 [`config.example.yaml`](config.example.yaml)。主要文件如下：

- `config.yaml`：飞书凭据和服务设置。macOS 使用 `0600`；Windows 使用仅当前用户可访问的受保护 ACL。
- `state.json`：每个飞书用户的当前任务、数字列表快照、最后使用的通知会话，以及未完成任务的恢复状态。
- `installed-version`：当前后台服务实际启动的程序版本，供单文件自动更新验证使用。
- `logs/im2agent-YYYY-MM-DD.log`：按天滚动的 JSON 日志。
- 附件缓存：按任务、日期和消息 ID 分目录保存。

默认日志和附件均保留 30 天。日志记录飞书用户消息正文及必要的消息元数据，不记录 Codex 最终回复，也不记录附件内容。附件没有应用层大小限制，但仍受飞书平台接口限制；下载过程会直接流式写入磁盘。

## Codex 连接方式与已知限制

`im2agent` 使用 Codex CLI 的实验性 app-server JSONL 协议，并会在未检测到 Codex 桌面应用时自动启动它：

- Windows 和 macOS：从桌面应用安装目录启动一个专用于 `im2agent` 的 stdio app-server。它与桌面应用共享登录状态和任务存储，活动任务通过桌面 IPC 同步。macOS 同时兼容新版 `ChatGPT.app` 和旧版 `Codex.app`，不要求额外安装 standalone Codex CLI。

当前协议仍是实验性能力，Codex 升级后可能需要同步协议字段。由于运行进程之间的边界，桌面端已经发起的活动轮次不能可靠地由飞书消息 steer；这种情况下服务会返回任务忙碌。桌面端发起的执行也不会主动推送到飞书。

## 手工配置

如果扫码注册不可用，可复制示例配置到对应配置目录并填写：

```yaml
feishu:
  app_id: "cli_xxx"
  app_secret: "xxx"
```

机器人需要启用飞书机器人能力、`im:message`、`im:message:send_as_bot`、`im:resource` 权限，订阅 WebSocket 长连接消息事件 `im.message.receive_v1` 和互动卡片回调 `card.action.trigger`。新版首次扫码注册会自动申请这些配置。已有机器人配置不完整时，可执行下面的命令并扫码确认一次增量更新：

```bash
im2agent --configure-feishu
```

扫码确认并按飞书页面提示发布版本后重新启动服务。旧参数 `--configure-feishu-callbacks` 仍然兼容。一个 `im2agent` 进程只连接一个飞书机器人。

## 本地构建与验证

需要 Go 1.24 或更高版本：

```bash
go test ./...
go vet ./...
go build ./cmd/im2agent
```

用于分发和自动比较的本地构建需要写入规范版本号：

```bash
VERSION="v$(date +%Y.%m%d.%H%M)"
go build -trimpath -ldflags "-s -w -X main.version=${VERSION}" -o im2agent ./cmd/im2agent
```

Windows PowerShell：

```powershell
$version = Get-Date -Format "'v'yyyy.MMdd.HHmm"
go build -trimpath -ldflags "-s -w -X main.version=$version" -o im2agent.exe ./cmd/im2agent
```

可选的只读本机 Codex 集成测试要求先启动 Codex 桌面应用：

```bash
IM2AGENT_LIVE_CODEX=1 go test ./internal/codex -run TestLiveDesktopConnection -v
```

Windows PowerShell：

```powershell
$env:IM2AGENT_LIVE_CODEX = "1"
go test ./internal/codex -run TestLiveDesktopConnection -v
```

## 项目结构

```text
cmd/im2agent       命令行入口
internal/app       指令、任务路由、运行与审批协调
internal/codex     app-server JSON-RPC 客户端和进程连接
internal/feishu    飞书 WebSocket、卡片、附件和扫码注册
internal/im        可扩展 IM 适配器接口
internal/config    配置、路径和凭据权限
internal/state     每用户状态持久化
internal/logging   日志轮转与清理
internal/autostart Windows 任务计划与 macOS LaunchAgent
internal/selfupdate 单文件和飞书在线更新、下载校验、备份替换、验证与回滚
```

## License

MIT
